# TwistedLoopMod
A mod that spawns a blue portal upon defeating the Twisted Scavenger boss on A Moment, Whole. Allows for infinite single-run lunar coin farming!

#Changelog
v1.1.0:
-Updated method for portal creation. Still currently only possible to spawn Blue Portal.
-Portal should now spawn relative to the host for increased multiplayer compatibility.
-Potential plans to be able to spawn any portal upon defeating the Twisted Scavenger.

v1.0.0:
-Initial release of mod
-Blue Portal spawns at random location in A Moment, Whole.