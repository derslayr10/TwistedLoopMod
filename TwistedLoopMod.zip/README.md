# TwistedLoopMod
A mod that spawns a blue portal upon defeating the Twisted Scavenger boss on A Moment, Whole. Allows for infinite single-run lunar coin farming!
